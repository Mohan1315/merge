echo "old"
orignal=("Anushtha","Harshita","Mohan")
copy=${orignal[*]}
echo $orignal

echo $copy ${copy[1]}

read a
read b
a+=$b
echo $a

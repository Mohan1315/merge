echo "This is my first shell script"
echo "Today's date is 18:01:24"
echo "Now the time is 11:16:00"

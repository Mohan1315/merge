read a
read b
read c
d=$((a+b+c))
e=$(((a+b)*c))
f=$(((a+b)/c))
echo $d
echo $e
echo $f

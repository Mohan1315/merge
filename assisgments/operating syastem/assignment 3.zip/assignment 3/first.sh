echo "This is my first shell script"
current_date="Today's date is `date +%d:%m:%Y`";
current_time="Now the time is `date +%H:%M:%S`";
echo $current_date;
echo $current_time;

read -p "enter the first string : " str1
read -p "enter the second string : " str2
str1+=$str2;
echo "$str1"
